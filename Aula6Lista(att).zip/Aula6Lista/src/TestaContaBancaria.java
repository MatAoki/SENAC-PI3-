public class TestaContaBancaria {
    public static void main(String[] args) {
        
        ContaCorrente CC = new ContaCorrente(0, 800);
        ContaPoupanca CP = new ContaPoupanca(1, 500);
        
        CC.depositar(25.60);
        CP.depositar(56.90);
        
        CC.sacar(10.00);
        CP.sacar(700);
        
        Relatorio R = new Relatorio();
        
        R.gerarRelatorio(CC);
        R.gerarRelatorio(CP);
        
        
        
    }
    
}
