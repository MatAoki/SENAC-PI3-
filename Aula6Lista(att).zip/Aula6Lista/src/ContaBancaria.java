import java.util.ArrayList;
public abstract class ContaBancaria implements Imprimivel {
    
    protected int numeroConta;
    protected double saldo;

    public ContaBancaria(int numeroConta, double saldo) {
        this.numeroConta = numeroConta;
        this.saldo = saldo;
    }
    
        public ContaBancaria(int numeroConta) {
        this.numeroConta = numeroConta;
        this.saldo = 0;
    }
    
    /*public ContaBancaria() {
        this.numeroConta = 0;
        this.saldo = 0;
    }*/
    
    public abstract double sacar(double valor);
    public abstract double depositar(double valor);
    
    public void transferir (double valor, ContaBancaria C){
        this.sacar(valor);
        C.depositar(valor);
    } 
    
//getter e setter
    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    
    
}
