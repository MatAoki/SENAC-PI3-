public class ContaPoupanca extends ContaBancaria implements Imprimivel{
    
    protected double limite = -200;

    public ContaPoupanca(int numeroConta, double saldo) {
        super(numeroConta, saldo);
    }
    
    public ContaPoupanca(int numeroConta) {
        super(numeroConta);
    }
    
    public double sacar(double valor){
        if (getSaldo()-valor < this.limite){
            System.out.println("Saldo indisponivel para saque.");
            return getSaldo();
        }

        setSaldo(getSaldo()- valor);
        return getSaldo();
    }
    
    public double depositar(double valor){
        setSaldo(getSaldo() + valor);
        return getSaldo();
        
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    public void mostrarDados(){
        System.out.println("Numero:" + getNumeroConta());
        System.out.println("Saldo: " + getSaldo());
        System.out.println("Limite de crédito: " + getLimite()+"\n");
    }    
}
