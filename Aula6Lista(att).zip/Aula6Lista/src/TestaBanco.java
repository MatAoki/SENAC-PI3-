import java.util.Scanner;
import java.util.ArrayList;

public class TestaBanco {
    public static void main(String[] args) {
        
        
        Banco B = new Banco();
        Scanner scan = new Scanner(System.in);
        int numConta;
        double Valor;

        System.out.println("Selecione a Operaçao:");
        System.out.println("1 - Criar Conta");
        System.out.println("2 - Selecionar Conta");
        System.out.println("3 - Remover Conta");
        System.out.println("4 - Gerar Relatorio");
        System.out.println("5 - Finalizar\n");
        
        int opt = scan.nextInt();
        
        while (opt != 5){
        
            if (opt == 1){
                System.out.println("Selecione o tipo de conta:");
                System.out.println("1 - Conta Poupanca");
                System.out.println("2 - Conta Corrente\n");
                opt = scan.nextInt();

                if (opt == 1){
                    System.out.println("Insira numero da conta popanca\n");
                    numConta = scan.nextInt();
                    ContaPoupanca CP = new ContaPoupanca(numConta);
                    ContaBancaria CB = CP;
                    B.inserir(CB);
                }

                else if(opt == 2){
                    System.out.println("Insira numero da conta corrente\n");
                    numConta = scan.nextInt();
                    ContaCorrente CC = new ContaCorrente(numConta);
                    ContaBancaria CB = CP;
                    B.inserir(CB);
                }
            }

            else if (opt == 2){
                
                System.out.println("Insira numero da conta");
                numConta = scan.nextInt();
                ContaBancaria Operadora = B.procurarConta(numConta);

                System.out.println("Selecione a Operacao");
                System.out.println("1 - Depositar");
                System.out.println("2 - Sacar");
                System.out.println("3 - Transferir");
                System.out.println("4 - Gerar Relatorio");
                System.out.println("5 - Voltar ao Menu\n");
                
                int opt2 = scan.nextInt();
                
                if (opt2 == 1){
                    System.out.println("Insira valor a ser depositado:");
                    Valor = scan.nextDouble();
                    Operadora.depositar(Valor);
                }
                
                else if(opt2 == 2){
                    System.out.println("Insira valor a ser sacado:");
                    Valor = scan.nextDouble();
                    Operadora.sacar(Valor);
                }
                
                else if(opt2 == 3){
                    System.out.println("Insira numero da conta para transferir");
                    numConta = scan.nextInt();
                    ContaBancaria Recebedor = B.procurarConta(numConta);
                    System.out.println("Insira valor a ser transferido:");
                    Valor = scan.nextDouble();
                    Operadora.transferir(Valor, Recebedor);
                }
                
                else if(opt2 == 4){
                    Operadora.mostrarDados();
                }
                
                else if(opt2 == 5){
                    System.out.println("Selecione a Operaçao:");
                    System.out.println("1 - Criar Conta");
                    System.out.println("2 - Selecionar Conta");
                    System.out.println("3 - Remover Conta");
                    System.out.println("4 - Gerar Relatorio");
                    System.out.println("5 - Finalizar\n");
                    
                }


            }

            else if (opt == 3){
                System.out.println("Insira numero da conta popanca\n");
                numConta = scan.nextInt();
                B.remover(B.procurarConta(numConta));

            }

            else if (opt == 4){
                B.mostrarDados();
            }
            
            else{
                System.out.println("Operacao invalida");
            }
            
            opt = scan.nextInt();
                
        }
        if (opt == 5)
            System.out.println("Aplicacao finalizada\n");
        
    }
    
}
