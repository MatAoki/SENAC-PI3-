public class Administrador extends Empregado{
    
    private double ajudaDeCusto;
    
    public Administrador(){
        super();
    }
    
    @Override
    public double calcularSalario(double salarioBase, double imposto){
        this.setSalarioBase(salarioBase);
        this.setImposto(imposto);
        return this.ajudaDeCusto+this.getSalarioBase()-this.getImposto();
        
    }
    
}
