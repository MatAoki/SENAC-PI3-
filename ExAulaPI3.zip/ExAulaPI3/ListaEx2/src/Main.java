public class Main {
    public static void main(String[] args) {
        Pessoa A = new Pessoa("Enzo", "logo ali", "70707070" );
        Pessoa B = new Pessoa("Maria");
        Pessoa C = new Pessoa();
        
        A.Imprime();
        B.Imprime();
        C.Imprime();
        
        Fornecedor D = new Fornecedor("Enzo Gabriel", "aqui perto", "70707070", 150.50, 100.0);
        D.Imprime();
        System.out.println("saldo = "+D.obterSaldo());
        System.out.println("");
        
        Empregado E = new Empregado("Enzo Gabriel", "logo ali", "70707070", 1234);
        E.Imprime();
        System.out.println("Salario: "+E.calcularSalario(2000.50, 200));
        System.out.println("");
        
   
    }
    
}
