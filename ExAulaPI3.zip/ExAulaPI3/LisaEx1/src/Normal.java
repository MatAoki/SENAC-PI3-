public class Normal extends Ingresso{
    
    public Normal(){
        super();
    }
    
    public void imprimeNormal(){
        System.out.println("Ingresso Normal");
    }
}
