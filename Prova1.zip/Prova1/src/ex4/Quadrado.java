package ex4;

/**
 *
 * @author matheus.maoki
 */
public class Quadrado extends Retangulo{
    protected double lado;
    protected double altura;

    public Quadrado(double lado) {
        super(lado, lado);
        this.lado = lado;
        this.altura = lado;
    }

    public Quadrado() {
        super();
        this.lado = 0;
    }
    
    
    
    
}
