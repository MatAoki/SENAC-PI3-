package ex4;

/**
 *
 * @author matheus.maoki
 */
public class Circulo extends Forma{
    
    protected double raio;

    public Circulo(double raio) {
        super();
        this.setRaio(raio);
    }

    public Circulo() {
        super();
        this.setRaio(0);
    }
    
    
    
    @Override
    double calcularArea(){
        return Math.PI*Math.pow(this.getRaio(), 2);
    }
    
    @Override
    double calcularPerimetro(){
        return 2*Math.PI*this.getRaio();
    }
    
//*******************************************//
    //getter e setter
    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }
    
    
}
