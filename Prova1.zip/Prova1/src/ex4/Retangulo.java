package ex4;

/**
 *
 * @author matheus.maoki
 */
public class Retangulo extends Forma{
    
    protected double lado;
    protected double altura;

    public Retangulo(double lado, double altura) {
        super();
        this.setLado(lado);
        this.setAltura(altura);
    }
    
    public Retangulo() {
        super();
        this.setLado(0);
        this.setAltura(0);
    }
    
    @Override
    double calcularArea(){
        return this.getLado()*this.getAltura();
    }
    
    @Override
    double calcularPerimetro(){
        return this.getLado()*2 + this.getAltura()*2;
    }
    
    //**************************************//
    //getter e setter
    
    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
}
