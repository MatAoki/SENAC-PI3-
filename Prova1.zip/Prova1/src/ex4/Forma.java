package ex4;

/**
 *
 * @author matheus.maoki
 */
public abstract class Forma {
    
    abstract double calcularArea();
    abstract double calcularPerimetro();
    
}
