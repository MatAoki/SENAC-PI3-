package ex4;

import java.util.ArrayList;

/**
 *
 * @author matheus.maoki
 */
public class ListaForma {
    
    ArrayList <Forma> array = new ArrayList <>();
    
    public void adicionarForma(Forma f){
        array.add(f);
    }
    
    public void removeForma(int ind){
        array.remove(ind);
    }
    
    public void imprimeLista(){
        for (int i = 0; i < array.size(); i++) {
            System.out.println("Area:"+ array.get(i).calcularArea());
            System.out.println("Perimetro: "+ array.get(i).calcularPerimetro());
            System.out.println("");
            
        }
    }
    
}
