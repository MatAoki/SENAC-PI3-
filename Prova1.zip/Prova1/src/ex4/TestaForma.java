package ex4;

/**
 *
 * @author matheus.maoki
 */
public class TestaForma {
    public static void main(String[] args) {
        
        Retangulo r1 = new Retangulo(1,2);
        Quadrado q1 = new Quadrado(3);
        Circulo c1 = new Circulo(1);
    
        ListaForma lf = new ListaForma();
        
        lf.adicionarForma(r1);
        lf.adicionarForma(q1);
        lf.adicionarForma(c1);
        
        lf.imprimeLista();
    
    }

}
