package ex2;

/**
 *
 * @author matheus.maoki
 */
public class ListaPontos {
    private Ponto pontos[];
    private int qtd;
    public void listPontos(){
        pontos = new Ponto [100];
        qtd = 0;
    }
    
    public void adicionas(Ponto p){
        pontos [qtd++] = p;
    }
    
    public void remove (Ponto p){
        for (int i = 0; i < qtd; i++) {
            if (p.igual(pontos[i])){
                for (int j = i; j < qtd; j++) {
                    pontos[j] = pontos[j+1];
                }
                qtd--;
                return;
            }
        }
        System.out.println("ponto nao encontrado");
    }
    
    public double menorDistancia(){
        
        double md = pontos[0].distancia(pontos[1]);
        
        for (int i = 0; i < qtd; i++) {
            for (int j = 0; j < qtd; j++) {
                if(pontos[i].distancia(pontos[j]) < md && pontos[i].distancia(pontos[j])!= 0){
                    md = pontos[i].distancia(pontos[j]);
                }
            }
        }
        return md;
    }
    
}
