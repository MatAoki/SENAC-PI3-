/**
 *
 * @author matheus.maoki
 */
public class Main {
    public static void main(String[] args) {
        
        fracao f1 = new fracao(1,2);
        fracao f2 = new fracao(2,4);
        fracao f3 = new fracao(5,2);
        
        System.out.println("fracao 1: ");
        System.out.println("numerador = " + f1.getA());
        System.out.println("denominador = " + f1.getB());
        System.out.println("");
        System.out.println("fracao 2: ");
        System.out.println("numerador = " + f2.getA());
        System.out.println("denominador = " + f2.getB());
        System.out.println("");
        System.out.println("fracao 3: ");
        System.out.println("numerador = " + f3.getA());
        System.out.println("denominador = " + f3.getB());
        System.out.println("");

        f1.soma(f2);
        f1.igualdade(f2);
        
        f1.soma(f3);
        f1.igualdade(f3);
        
    }
}
