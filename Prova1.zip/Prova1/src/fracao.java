/**
 *
 * @author matheus.maoki
 */
public class fracao {
    private int a;//numerador
    private int b;//denominador

    //construtor
    public fracao(int a, int b) {
        this.a = a;
        this.b = b;
    }
    
    //classe soma
    public fracao soma(fracao f){
        fracao s = new fracao(0,0);
        s.setA( (this.getA()*f.getB()) + (f.getA()*this.getB()) );
        s.setB(this.getB()*f.getB());
        System.out.println("numerador da soma: "+s.getA());
        System.out.println("denominador da soma: "+s.getB());
        System.out.println("");
        return s;
    }
    
    //classe igualdade
    public boolean igualdade(fracao f){
        if (this.getA()*f.getB() == this.getB()*f.getA()){
            System.out.println("igual\n");
            return true;
        }
        else {
            System.out.println("diferente\n");
            return false;
        }
    }

    
    
//******************************************//
    //getter e setter
    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
    
    
}
